
<form action="">
<label for="w3review">Review of W3Schools:</label>
<textarea id="w3review" name="w3review" rows="4" cols="50">
 
  </textarea>
  <br><br>
  <input type="submit" value="Submit">
</form>