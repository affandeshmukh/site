<html>

<head>
    <title>Example for HTML Marquee Tag</title>
</head>

<marquee width="40%" direction="up" height="30%"></br>
  <h1><strong>This is image marquee</strong></h1>   
<img src="/site/tem/images/brown.png">

   

</marquee>
<marquee width="40%" direction="down" height="30%">
   <h1><strong> direction down</strong></h1>
</marquee>
<marquee width="40%"  " direction="left" height="30%">
  <h1><strong>  direction left</strong></h1>
</marquee>
<marquee width="40%" direction="right" height="30%">
  <h1><strong>  direction right</strong></h1>
</marquee>
</html>