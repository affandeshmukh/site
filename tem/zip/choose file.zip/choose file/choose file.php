<!DOCTYPE html>
<html>
<body>

<p>Click on the "Choose File" button to upload a file:</p>

<form action="/site/success.php">
  <input type="file" id="myFile" name="filename">
  <input type="submit">
</form>

</body>
</html>