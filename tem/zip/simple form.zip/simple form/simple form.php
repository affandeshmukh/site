 <!DOCTYPE html>
<html>
<head>
	<style>
 .myDiv {

  text-align: left;
}
</style>
 </head>
 <body>
 	<form action="success.html">
<div class="myDiv">
<h5>First Name:</h5>
<input type="text" placeholder="Enter" required>
<h5>Last Name:</h5>
<input type="text" placeholder="Enter" required>
<h5>Address:</h5>
<input type="text" placeholder="Enter" required>
<h5>Phone Number:</h5>
<input type="text" placeholder="Enter" required>
</br>

<input type="submit">
</form>

</body>
</html>
